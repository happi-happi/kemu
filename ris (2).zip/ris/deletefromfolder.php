<?php
/***********************************************************
* Created By: Mussa Johanes Singano                        *
* File Name: receivedfromcamera.php                              *
* Date: 03 June 2024                                      *
************************************************************/
$db = new mysqli('localhost', 'root', '', 'ris');
if ($db->connect_errno > 0) {
    die('Unable to connect to database [' . $db->connect_error . ']');
}
// Check if data is received via POST
$dir = "./anpr/done/";
if (file_exists($dir)) {
    // Open a known directory and process its contents
    $files = scandir($dir);
    // Remove '.' and '..' from the array of filenames
    $imageNames = array_diff($files, ['.', '..']);

    foreach ($imageNames as $imageName) {
        // Sanitize the image name if needed (to prevent SQL injection)
        $sanitizedImageName = $db->real_escape_string($imageName);

        // Construct the SQL query to check if the image exists in the database table
        $checkSql = "SELECT COUNT(*) as count FROM hitlist WHERE images = '$sanitizedImageName'";
        $result = $db->query($checkSql);

        if ($result) {
            // Fetch the count from the result set
            $row = $result->fetch_assoc();
            $count = $row['count'];
    
            // Check if the image exists based on the count
            if ($count == 0) {
                // Image exists in the database
                unlink($dir.$imageName);
                $message = 'Successful image deleted';
                writeLog($message);
            }
        } else {
            // Handle query error (if any)
            $message = "Error: " . $db->error;
            writeLog($message);
        }
    
        // Free the result set
        $result->free();
    }

}else{
    $message = "Directory not exist";
    writeLog($message);
}

// Function to write logs
function writeLog($message) {
    // Example log file path
    $logFile = 'logs.txt';
    
    // Format log message with timestamp
    $logMessage = date('[Y-m-d H:i:s]') . ' ' . $message . PHP_EOL;

    // Write to log file (append mode)
    file_put_contents($logFile, $logMessage, FILE_APPEND | LOCK_EX);

    // Uncomment the line below if you want to see confirmation message in the output
    // echo "Logs have been written to {$logFile}";
}

?>
