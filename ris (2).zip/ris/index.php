<?php
/***********************************************************
* Created By: Mussa Johanes SIngano                        *
* File Name: camera stream.php                                  *
* Date: 03 June 2024                                      *
************************************************************/

error_reporting(0);

// Base URL for redirection
$base_url = 'http://localhost/ris/'; 
header("refresh:1;url=" . $base_url . "index.php");

// Database connection
$OFFLINE = false; // Set to true for offline mode, false for online mode
$db = new mysqli('localhost', 'root', '', 'ris');
if ($db->connect_errno > 0) {
    die('Unable to connect to database [' . $db->connect_error . ']');
}
// Include necessary files
include('process.php');
?>

<!DOCTYPE html>
<html lang="en">
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>RIS[Latra]</title>

  <!-- Google Font: Source Sans Pro -->
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="dist/css/all.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
  <link rel="icon" type="image/png" href="images/logoLatra.png">
  
  <!-- Custom Styles for Navigation -->
  <style>
    .navbar {
      background-color: #343a40; /* Dark background color */
      color: #ffffff; /* Text color */
      padding: 10px 0; /* Padding top and bottom */
      text-align: center; /* Center align text */
      margin-bottom: 20px; /* Margin bottom */
    }
    .navbar-brand {
      font-size: 24px; /* Adjust font size */
      font-weight: bold; /* Bold font weight */
      /* text-transform: uppercase;  */
      letter-spacing: 2px; /* Letter spacing */
      display: inline-block; /* Ensure inline block display */
      margin: 0 auto; /* Center align horizontally */
      text-align: center; /* Center align text */
      width: 100%; /* Ensure full width */
    }
  </style>
</head>
<body class="">

<div class="container-fluid">
  <!-- Top Navigation Bar -->
  <nav class="navbar" style="background-color: rgb(235, 136, 35);">
    <div class="container-fluid">
        <div class="row w-100 align-items-center">
            <!-- Left Column: Image -->
            <div class="col-auto">
                <img src="images/logoTz.png" alt="Left Logo" style="height: 50px;">
            </div>
            
            <!-- Center Column: Heading -->
            <div class="col text-center">
                <h1 class="my-0">L-RICS [Latra - Road Side Inspection Camera System]</h1>
            </div>
            
            <!-- Right Column: Image -->
            <div class="col-auto">
                <img src="images/logoLatra.png" alt="Right Logo" style="height: 50px;">
            </div>
        </div>
    </div>
</nav>
  <!-- Main Content Section -->
  <div class="card">
    <div class="card-body">
      <div class="row">
        <div class="col-md-5">
          <div class="card">
            <div class="card-header" style="background-color:<?php echo $color?>;">
              <h2>Camera Stream [VEHICLE: <b><?php echo ($formattedName != '10.0.6.6') ? $formattedName : 'NONE' ?></b>]</h2>
            </div>
            <div class="card-body">
              <div class="row">
                <div class="col-md-12 text-center" style="">
                  <img src="<?php echo $image ?>" style="width: 600px; height: 400px;" />
                </div>
              </div>
            </div>
            <div class="card-footer">
              <div class="row">
                <div class="col-md-12 text-center">
                
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-7">
          <div class="card">
            <div class="card-header">
              <h2>Non Compliance Vehicle [VEHICLE:<b>
              <?php
                            // Get today's date in the format 'Y-m-d'
                            $todayDate = date('Y-m-d');

                            // SQL Query: Count rows where tdate is today
                            $checkSql = "SELECT COUNT(*) AS count FROM hitlist WHERE DATE(tdate) = '$todayDate'";

                            // Execute the query
                            $checkResult = $db->query($checkSql);

                            if ($checkResult) {
                                // Fetch the result row
                                $row = $checkResult->fetch_assoc();
                                $countTodayRows = $row['count'];

                                echo "($todayDate): " . $countTodayRows;
                            } else {
                                echo "Error: " . $db->error;
                            }
                            ?>
                </b>]</h2>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-12" style="overflow-y: auto;height:400px;">
                    <table class="table table-bordered table-striped" style="width: 100%;text-align:center;">
                        <thead>
                            <tr>
                                <th><h4>Vehicle</h4></th>
                                <th><h4>Service</h4></th>
                                <th><h4>License</h4></th>
                                <th><h4>Offence</h4></th>
                                <th><h4>Image</h4></th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php
                                $sql = "SELECT * FROM hitlist WHERE DATE(tdate) = '$todayDate' ORDER BY id DESC LIMIT 10;";

                                if ($result = $db->query($sql)) {
                                    if ($result->num_rows > 0) {
                                        while ($row = $result->fetch_assoc()) {
                                            echo '<tr>';
                                            echo '<td style="font-size: 20px;padding-top:40px;">' . $row['vehicle'] . '</td>';
                                            echo '<td style="font-size: 20px;padding-top:40px;">' . mb_strtoupper($row['services']) . '</td>';
                                            echo '<td style="font-size: 20px;padding-top:40px;">' . $row['licence'] . '</td>';
                                            echo '<td style="font-size: 20px;padding-top:40px;">' . $row['offence'] . '</td>';
                                            echo '<td><img src="anpr/done/' . $row['images'] . '" style="width: 100px; height: 100px; align:center;" /></td>';
                                            echo '</tr>';
                                        }
                                    } else {
                                        echo '<tr><td colspan="5" style="text-align: center;font-size: 20px;">No records found</td></tr>';
                                    }
                                } else {
                                    echo '<tr><td colspan="5" style="text-align: center;">Error: ' . $db->error . '</td></tr>';
                                }
                            ?>
                        </tbody>
                    </table>
                    </div>
                </div>
            </div>
            <div class="card-footer">
              <div class="row">
                <div class="col-md-12 text-center">
                
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="card-footer text-muted">
      <div class="row">
        <div class="col-md-12">
          <p class="float-left">&copy; 2024-<?php echo date('Y'); ?> <a href="https://adminlte.io">Latra | ICT</a>. All rights reserved.</p>
          <p class="float-right">Version 1.0.0</p>
        </div>
      </div>
    </div>
  </div>
</div>
</body>
</html>

