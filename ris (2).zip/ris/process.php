<?php
/***********************************************************
* Created By: Mussa Johanes SIngano                        *
* File Name: process.php                                  *
* Date: 03 June 2024                                      *
************************************************************/

$dir = "./anpr/new/";
$dir2 = "./anpr/done/";
$image = 'blank.png';
$formattedName = 'NONE';

$url = 'http://41.59.102.217:8086';
$clientId = '486afa20-e68d-415a-a1f0-80f402923300';
$clientSecret = 'd5a5847b-99e2-4ba4-ad28-91d9cc39d08c';

$db = new mysqli('localhost', 'root', '', 'ris');
if ($db->connect_errno > 0) {
    die('Unable to connect to database [' . $db->connect_error . ']');
}
date_default_timezone_set('Africa/Dar_es_Salaam'); // Example timezone, replace with your timezone

// Check if the source directory exists
if (file_exists($dir)) {
    // Open a known directory and process its contents
    $files = scandir($dir);
    // Remove '.' and '..' from the array of filenames
    $imageNames = array_diff($files, ['.', '..']);
    if (empty($imageNames)) {
        // include('sendtoserver.php');
    }else{
        // Format and move each image file
        foreach ($imageNames as $imageName) {
            
            // Extract the substring
            $subString = trim(substr($imageName, 0, 7));
            // Check the length of the substring
            if (strlen($subString) == 6) {
                // Concatenate 'T' with the substring if its length is 6
                $formattedName = 'T' . $subString;
            } elseif (strlen($subString) == 7) {
                // Replace the first character with 'T' if its length is 7 and it doesn't start with 'T'
                $formattedName = 'T' . substr($subString, 1);
            } else {
                // Skip if the length is neither 6 nor 7
                continue;
            }
            $pattern = '/^T\d{3}[A-Z]{3}$/';
            // Check if the formatted name matches the pattern
            if (!preg_match($pattern, $formattedName)) {
                // Delete the file permanently if it doesn't match the format
                $filePath = $dir . $imageName;
                if (file_exists($filePath)) {
                    unlink($filePath); // Delete the file
                }
                continue;
            }
            //rename file after formatted
            $nameImange = $formattedName.'.jpg';
            rename($dir.$imageName, $dir2.$nameImange);
            $image = $dir2.$nameImange;
            //path according files
            $sourcePath = $dir . $nameImange;
            // Example request data for verifyLicense
            $requestData = [
                'vehicleRegistrationNumber' => $formattedName,
                'certificateNumber' => "",
                'driverLicenceNumber' => "",
            ];

            // Call the verifyLicense method to get response data
            $licenseData = verifyLicence($requestData);
            // Call the verifyOffence method to get response data
            $offenceData = verifyOffence($requestData);

            $licenseResponse = isset($licenseData['data']['licenseResponse']) ? $licenseData['data']['licenseResponse'] : null;
            $offencesResponse = isset($offenceData['offences']) ? $offenceData['offences'] : [];

            $hasUnpaidOffence = false;
            $hasPaidOffence = false;
            
            // Iterate through offences to check payment status
            foreach ($offencesResponse as $offence) {
                if ($offence['paymentStatus'] === "UNPAID") {
                    $hasUnpaidOffence = true;
                } elseif ($offence['paymentStatus'] === "PAID") {
                    $hasPaidOffence = true;
                }
            }

            $licenseStatus = isset($licenseResponse['licenseStatus']) ? $licenseResponse['licenseStatus'] : null;
            $service = isset($licenseResponse['serviceType']) ? $licenseResponse['serviceType'] : null;

            // Check if there's an existing record within the last 5 minutes
            $fiveMinutesAgo = date('Y-m-d H:i:s', strtotime('-5 minutes'));
            $checkSql = "SELECT COUNT(*) AS count FROM hitlist WHERE vehicle = '$formattedName' AND tdate >= '$fiveMinutesAgo'";
            $existingRecord = $db->query($checkSql);
            $row = $existingRecord->fetch_assoc();
            $count = $row['count'];

            if ($licenseResponse !== null && !empty($offencesResponse)) {
                if (($licenseStatus === "EXPIRED" || $licenseStatus === "ACTIVE") && $hasUnpaidOffence) {
                    // Both license is expired or active and there is at least one unpaid offence
                    if ($count == 0) {
                        // Insert data into hitlist table
                        $insertSql = "INSERT INTO hitlist (vehicle, licence, services, images) VALUES (?, ?, ?, ?)";
                        $stmt = $db->prepare($insertSql);
                        $stmt->bind_param("ssss", $formattedName, $licenseStatus, $service, $nameImange);
                        if ($stmt->execute()) {
                            // New record inserted successfully
                        } else {
                            // Log the error
                            error_log("Error: " . $stmt->error);
                        }
                        $stmt->close();
                    }
                } elseif ($licenseStatus === "EXPIRED" && $hasPaidOffence) {
                    if ($count == 0) {
                        // Insert data into hitlist table
                        $insertSql = "INSERT INTO hitlist (vehicle, licence, offence, services, images) VALUES (?, ?, 'NO OFFENCE', ?,?)";
                        $stmt = $db->prepare($insertSql);
                        $stmt->bind_param("ssss", $formattedName, $licenseStatus, $service, $nameImange);
                        if ($stmt->execute()) {
                            // New record inserted successfully
                        } else {
                            // Log the error
                            error_log("Error: " . $stmt->error);
                        }
                        $stmt->close();
                    }
                }
                unlink($sourcePath);
            
            } else if ($licenseResponse !== null && empty($offencesResponse)) {
                if ($licenseStatus === "EXPIRED") {
                    if ($count == 0) {
                        // Insert data into hitlist table
                        $insertSql = "INSERT INTO hitlist (vehicle, licence, offence, services, images) VALUES (?, ?, 'NO OFFENCE', ?, ?)";
                        $stmt = $db->prepare($insertSql);
                        $stmt->bind_param("ssss", $formattedName, $licenseStatus, $service, $nameImange);
                        if ($stmt->execute()) {
                            // New record inserted successfully
                        } else {
                            // Log the error
                            error_log("Error: " . $stmt->error);
                        }
                        $stmt->close();
                    }
                }
                unlink($sourcePath);
            
            } else if ($licenseResponse === null && !empty($offencesResponse)) {
                if ($hasUnpaidOffence) {
                    if ($count == 0) {
                        // Insert data into hitlist table
                        $insertSql = "INSERT INTO hitlist (vehicle, licence, offence, services, images) VALUES (?, 'NO LICENSE', ?, 'NOT REGISTERED', ?)";
                        $stmt = $db->prepare($insertSql);
                        $stmt->bind_param("sss", $formattedName, 'UNPAID', $nameImange);
                        if ($stmt->execute()) {
                            // New record inserted successfully
                        } else {
                            // Log the error
                            error_log("Error: " . $stmt->error);
                        }
                        $stmt->close();
                    }
                }
                unlink($sourcePath);
            } else {
                // Delete all images that do not match any of the above conditions
                unlink($sourcePath);
                
            }

        }
        
    }
    
}

function getAccessToken()
    {
        $url = 'http://41.59.102.217:8086/oauth/token';
        $clientId = '486afa20-e68d-415a-a1f0-80f402923300';
        $clientSecret = 'd5a5847b-99e2-4ba4-ad28-91d9cc39d08c';

        try {
            // Prepare request body
            $postData = [
                'grant_type' => 'client_credentials',
                'scope' => 'read', // Optional: Adjust based on your requirements
            ];

            // Initialize cURL session
            $curl = curl_init();

            // Set cURL options
            curl_setopt_array($curl, array(
                CURLOPT_URL => $url,
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_MAXREDIRS => 10,
                CURLOPT_TIMEOUT => 30,
                CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
                CURLOPT_CUSTOMREQUEST => 'POST',
                CURLOPT_POSTFIELDS => http_build_query($postData), // Convert array to URL-encoded query string
                CURLOPT_HTTPHEADER => array(
                    'Authorization: Basic ' . base64_encode("$clientId:$clientSecret"),
                    'Content-Type: application/x-www-form-urlencoded',
                ),
            ));

            // Execute cURL request and capture the response
            $response = curl_exec($curl);
            // Check for errors
            if (curl_errno($curl)) {
                $error = curl_error($curl);
                throw new \Exception("cURL Error: $error");
            }

            // Close cURL session
            curl_close($curl);

            // Check HTTP status code
            $statusCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);

            // Handle response based on status code
            if ($statusCode >= 200 && $statusCode < 300) {
                // Successful response
                $responseData = json_decode($response, true);

                // Extract and return access token
                $accessToken = $responseData['access_token'];

                return $accessToken;
                //echo "Access Token: $accessToken";
            } else {
                // Error response
                throw new \Exception("Failed to obtain access token. Status code: $statusCode, Error: " . $response);
            }
        } catch (\Exception $e) {
            // Handle any exceptions
            echo 'Error: ' . $e->getMessage();
        }
    }

function verifyLicence($requestData)
{
    global $url;

    $accessToken = getAccessToken();

    $link = $url . '/api/mobile/verify-license'; // Replace with your actual endpoint URL

    // Initialize cURL session
    $headers = [
        'Authorization: Bearer ' . $accessToken,
        'Content-Type: application/json',
    ];

    $curl = curl_init($link);
    curl_setopt_array($curl, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => json_encode($requestData),
        CURLOPT_HTTPHEADER => $headers,
        CURLOPT_TIMEOUT => 30,
    ]);

    $response = curl_exec($curl);

    // Check for errors
    if (curl_errno($curl)) {
        $error = curl_error($curl);
        throw new \Exception("cURL Error: $error");
    }

    // Close cURL session
    curl_close($curl);

    // Decode JSON response
    return json_decode($response, true);
}

function verifyOffence($requestData)
{
    global $url;

    $accessToken = getAccessToken();

    // Replace with your actual API endpoint URL
    $link = $url . '/api/mobile/check-offence';

    // Initialize cURL session
    $headers = [
        'Authorization: Bearer ' . $accessToken,
        'Content-Type: application/json',
    ];

    $curl = curl_init($link);
    curl_setopt_array($curl, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_POSTFIELDS => json_encode($requestData),
        CURLOPT_HTTPHEADER => $headers,
        CURLOPT_TIMEOUT => 30,
    ]);

    $response = curl_exec($curl);

    // Check for errors
    if (curl_errno($curl)) {
        $error = curl_error($curl);
        throw new \Exception("cURL Error: $error");
    }

    // Close cURL session
    curl_close($curl);

    // Decode JSON response
    return json_decode($response, true);
}
