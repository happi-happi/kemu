<?php
/***********************************************************
* Created By: Mussa Johanes Singano                        *
* File Name: receivedfromcamera.php                              *
* Date: 03 June 2024                                      *
************************************************************/
$db = new mysqli('localhost', 'root', '', 'ris');
if ($db->connect_errno > 0) {
    die('Unable to connect to database [' . $db->connect_error . ']');
}
// Check if data is received via POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Assuming data is sent as JSON, decode it
    $requestData = json_decode(file_get_contents('php://input'), true);

    if ($requestData !== null) {
        // Example data for response

        foreach ($requestData as $item) {
            // Access individual fields
            $id = $item['id'];
            $tdate = $item['tdate'];
            $vehicle = $item['vehicle'];
            $services = $item['services'];
            $licence = $item['licence'];
            $offence = $item['offence'];
            $image = $item['imgbase64'];
        
            $insertSql = "INSERT INTO  thitlist (tdate, vehicle, services, licence, offence, images) 
                          VALUES (?, ?, ?, ?, ?, ?)";
                        $stmt = $db->prepare($insertSql);
                        $stmt->bind_param("ssssss", $tdate, $vehicle, $services, $licence, $offence, $image);
                        if ($stmt->execute()) {
                            // New record inserted successfully
                        } else {
                            // Log the error
                            error_log("Error: " . $stmt->error);
                        }
                        $stmt->close();
        
            // Collect IDs into an array
            $ids[] = $id;
        }
         // Set HTTP response code
         http_response_code(399);
        // Prepare response data with collected IDs
        $responseData = [
            'ids' => $ids, // Assuming 'ids' is the key for the array of IDs
            'code' => 100, // Assuming 'code' is a key in the received data
            'status' => 'successful saved'
        ];
        
        // Set the appropriate headers for JSON response
        header('Content-Type: application/json');
        
        // Output JSON response
        echo json_encode($responseData);
    } else {
        // Error handling if JSON decoding fails
        $responseData = [
            'error' => 'Invalid JSON format'
        ];

        // Set HTTP response code
        http_response_code(400); // Bad Request

        // Set the appropriate headers for JSON response
        header('Content-Type: application/json');

        // Output JSON error response
        echo json_encode($responseData);
    }
} else {
    // Error handling for unsupported HTTP methods
    $responseData = [
        'error' => 'Method Not Allowed'
    ];

    // Set HTTP response code
    http_response_code(405); // Method Not Allowed

    // Set the appropriate headers for JSON response
    header('Content-Type: application/json');

    // Output JSON error response
    echo json_encode($responseData);
}
?>
