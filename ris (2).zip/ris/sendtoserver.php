<?php
/***********************************************************
* Created By: Mussa Johanes SIngano                        *
* File Name: sendtoserver.php                                  *
* Date: 03 June 2024                                      *
************************************************************/
date_default_timezone_set('Africa/Dar_es_Salaam'); // Example timezone, replace with your timezone

$db = new mysqli('localhost', 'root', '', 'ris');
if ($db->connect_errno > 0) {
    die('Unable to connect to database [' . $db->connect_error . ']');
}
//Directory path where images are located
$dir = "./anpr/done/";
// Calculate timestamp five minutes ago
$fiveMinutesAgo = date('Y-m-d H:i:s', strtotime('-15 minutes'));

// Get the current date
$currentDate = date('Y-m-d');

// Construct the SQL query to select records where tdate is not equal to the current date and not within the last five minutes
$selectSql = "SELECT * FROM hitlist WHERE DATE(tdate) != '$currentDate' OR tdate < '$fiveMinutesAgo'";
$result = $db->query($selectSql);

if ($result) {
    // Initialize an array to hold fetched rows
    $rows = array();

    // Fetch all rows from the result set
    while ($row = $result->fetch_assoc()) {
        $imageName = $row['images']; // Assuming 'images' is the column name in your database
        // Convert image to Base64
        $base64Image = imageToBase64($imageName, $dir);
        
        if ($base64Image !== null) {
            // Add Base64 image to the row
            $row['imgbase64'] = $base64Image;
            // Add the modified row to the array
            $rows[] = $row;
        } else {
            // Handle error if conversion fails (optional)
            // You may choose to skip this row or log an error
            echo "Error converting image for row with image name: $imageName\n";
        }
    }

    // Close the result set
    $result->close();

    // Check if there are rows to process
    if (!empty($rows)) {
        // Convert fetched rows to JSON format
        $jsonData = json_encode($rows);

        // Example log messages
        writeLog("Data fetched successfully: " . $jsonData);

        // Initialize cURL session
        $curl = curl_init();

        // Set cURL options
        curl_setopt_array($curl, array(
            CURLOPT_URL => 'http://172.16.16.152:8086/ris/receivedfromcamera.php', // Replace with your API endpoint
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_ENCODING => '',
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_CUSTOMREQUEST => 'POST',
            CURLOPT_POSTFIELDS => $jsonData, // Send the JSON data here
            CURLOPT_HTTPHEADER => array(
                'Content-Type: application/json', // Adjust the content type as needed
                'Content-Length: ' . strlen($jsonData)
            ),
        ));

        // Execute cURL request
        $response = curl_exec($curl);

        // Check for errors
        if (curl_errno($curl)) {
            writeLog('cURL Error: ' . curl_error($curl));
        } else {
            // Print API response
            // Decode the JSON string into a PHP associative array
            $responseData = json_decode($response, true);

            // Check if decoding was successful
            if ($responseData !== null) {
                // Access the data
                $ids = $responseData['ids']; // Array of IDs

                // Iterate over the IDs array and delete records from the table
                foreach ($ids as $id) {
                    // Perform delete query
                    $deleteSql = "DELETE FROM hitlist WHERE id = ?";
                    $stmt = $db->prepare($deleteSql);
                    
                    if ($stmt) {
                        // Bind parameter and execute query
                        $stmt->bind_param("s", $id); // Assuming id is a string, adjust if necessary
                        if ($stmt->execute()) {
                            // Deletion successful
                            echo "Record with ID $id deleted.\n";
                        } else {
                            // Error handling
                            echo "Error deleting record with ID $id: " . $stmt->error . "\n";
                        }
                        $stmt->close();
                    } else {
                        // Error preparing statement
                        echo "Error preparing statement: " . $db->error . "\n";
                    }
                }

                // Output the rest of the response data
                $code = $responseData['code']; // Status code
                $status = $responseData['status']; // Status message

                echo "\nCode: " . $code . "\n";
                echo "Status: " . $status . "\n";
            } else {
                // Handle JSON decoding error
                echo "Error decoding JSON.\n";
            }
            writeLog('API Response: ' . $response);
        }

        // Close cURL session
        curl_close($curl);
    } else {
        $message = "No records found where tdate is not equal to the current date and not within the last five minutes.";
        writeLog($message);
    }
} else {
    $message = "Error executing query: " . $db->error;
    writeLog($message);
}

// Function to write logs
function writeLog($message) {
    // Example log file path
    $logFile = 'logs.txt';
    
    // Format log message with timestamp
    $logMessage = date('[Y-m-d H:i:s]') . ' ' . $message . PHP_EOL;

    // Write to log file (append mode)
    file_put_contents($logFile, $logMessage, FILE_APPEND | LOCK_EX);

    // Uncomment the line below if you want to see confirmation message in the output
    // echo "Logs have been written to {$logFile}";
}

// Function to convert image file to Base64
function imageToBase64($imageName, $dir) {
    // Construct the full path to the image file
    $filePath = $dir . $imageName;

    // Check if the file exists
    if (file_exists($filePath)) {
        // Read the image file
        $imageData = file_get_contents($filePath);

        // Convert image data to Base64 format
        $base64Image = base64_encode($imageData);

        // Return the Base64 encoded string
        return $base64Image;
    } else {
        // File not found error handling (you can modify this as needed)
        echo "File $imageName not found in folder.";
        return null; // Or handle the error in another way
    }
}
